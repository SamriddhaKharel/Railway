DROP TABLE train;
DROP TABLE train_status;
DROP TABLE train_availability;
DROP TABLE bookings;
DROP TABLE passenger;